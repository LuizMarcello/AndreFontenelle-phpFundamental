<?php 
    $salario = 800;
    $meses   = 3;
?>

<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Curso PHP FUNDAMENTAL</title>
    </head>

    <body>
        <?php 
            // Multiplicacao e Divisao

            // Exponencial

            // Raiz Quadrada

            // Randômico Generica

            // Randômico entre um intervalo

            // Valor absoluto
            
        ?>
    </body>
</html>