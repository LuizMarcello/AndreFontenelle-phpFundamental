<?php
    $salario = 800;
    $gasolina = 2.79;
?>

<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Curso PHP FUNDAMENTAL</title>
    </head>

    <body>
        
        
        <?php
            // testar se é numérica


            // testar se é inteiro


            // testar se é float
        ?>
        
        
    </body>
</html>